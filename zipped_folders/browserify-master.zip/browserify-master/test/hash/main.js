t.equal(require('./foo/two.js'), 555);
t.equal(require('./one.js'), 333);
