t.equal(require('freelist')(5), 1005);
t.equal(require('./x.js')(6), 1016);
