module.exports = function() {
 console.log("a a")
};
