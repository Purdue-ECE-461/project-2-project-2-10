var a = require('./a.json');
var b = require('./b.json');

console.log('a=' + a.x);
console.log('b=' + b.x);
