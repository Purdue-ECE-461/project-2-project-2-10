var x = require('./x')
console.log(x)
