var x = {};
var y = 6;
