module.exports = 'foo';

// incremented on require ./b
baton.times++;

